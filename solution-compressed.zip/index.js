
const { processData } = require('./controllers/main-controller');

(async function main() {

    await processData();

})();
