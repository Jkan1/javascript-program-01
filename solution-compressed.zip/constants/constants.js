
exports.URL_1 = 'https://s3.amazonaws.com/static.nutritionix.com/1.json';

exports.URL_2 = 'https://s3.amazonaws.com/static.nutritionix.com/2.json';
