[17:35] Yurko Fedoriv

https://s3.amazonaws.com/static.nutritionix.com/1.json
https://s3.amazonaws.com/static.nutritionix.com/2.json
 
Load the content of the files from the URLs.
Merge 2 arrays into single one. 
Output the contents of the array sorted by ID
Output the contents of the array  sorted lex by type

[
  {
    "id":   1,
    "type": "DEV_A"
  },
  {
    "id":   3,
    "type": "PROD_B"
  }
]